#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include <vector>
#include <unordered_map>
#include <utility>
#include <algorithm>
#include <ctime>
#include <cmath>
#include <random>
#include <queue>
#include <unordered_set>
#include <string>
#include <assert.h>

using namespace std;

typedef int state;
struct state_vars;

extern const float INVALID;
extern int N, K;
extern float p, q, r, t;
extern int total_explored_states;

#endif